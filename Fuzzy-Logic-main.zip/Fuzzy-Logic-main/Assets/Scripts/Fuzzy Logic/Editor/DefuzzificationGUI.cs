using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Fuzzy_Logic.Editor
{
    public class DefuzzificationGUI : FuzzificationGUI
    {
        public DefuzzificationGUI(Defuzzification defuzzification):
            base(defuzzification)
        {
            // Do nothing
        }
    }
}