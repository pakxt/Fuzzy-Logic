using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Fuzzy_Logic
{
    public interface IGUI
    {
        void Draw();
    }
}